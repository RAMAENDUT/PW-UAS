<div id="reservation-popup" class="reservation-container reservation-popup mfp-hide p-3">
    <form id="reservation-form" action="">
        <?php echo csrf_field(); ?>

        <!-- One "tab" for each step in the form: -->
        <div class="tab">
            <h2>Reserve seats</h2>
            <?php echo $__env->make('components.cinema-view', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>

        <?php if(auth()->guard()->check()): ?>
        <div class="tab" style="display: none">
            <h2>Payment details</h2>
            <?php echo $__env->make('components.payment-view', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <?php endif; ?>


        <div style="overflow:auto;">
            <div style="float:right;" class="mt-3">
                <button type="button" id="prevBtn" class="btn btn-red" onclick="nextPrev(-1)">Previous</button>
                <button type="button" id="nextBtn" class="btn btn-green" onclick="nextPrev(1)">Next</button>
            </div>
        </div>

    </form>
</div>

<script src="<?php echo e(asset('js/reservations-popup.js')); ?>"></script><?php /**PATH D:\download\archive\UAS\Cinemat-main\resources\views/components/reservation-modal.blade.php ENDPATH**/ ?>
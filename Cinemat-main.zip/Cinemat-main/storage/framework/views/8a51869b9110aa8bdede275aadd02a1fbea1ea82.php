<!-- Movie List Item -->
<div class="col-md-12 col-sm-12">
    <div class="movie-list-2">
        <div class="listing-container">

            <!-- Movie List Image -->
            <div class="listing-image">

                <!-- Image -->
                <div class="img-wrapper">

                    <!-- Play Button -->
                    <div class="play-btn">
                        <a href="<?php echo e(route('movies.show', $movie->id)); ?>" class="play-video">
                            <i class="fa fa-ticket"></i>
                        </a>
                    </div>

                    <img src="<?php echo e(asset('storage/' . $movie->image)); ?>" alt="<?php echo e($movie->title); ?> Poster">
                </div>
            </div>

            <!-- Movie List Content -->
            <div class="listing-content">
                <div class="inner">
                    <h2 class="title"><?php echo e($movie->title); ?></h2>

                    <p><?php echo e($movie->storyline); ?></p>

                    <a href="<?php echo e(route('movies.show', $movie->id)); ?>" class="btn btn-main btn-effect">details</a>
                </div>


                <!-- Buttons -->
                <div class="buttons">
                    <a href="#" data-original-title="Rate" data-toggle="tooltip" data-placement="bottom">
                        <i class="icon-heart"></i>
                    </a>

                    <a href="#" data-original-title="Share" data-toggle="tooltip" data-placement="bottom">
                        <i class="icon-share"></i>
                    </a>
                </div>

                <!-- Rating -->
                <div class="stars">
                    <div class="rating">
                        <?php echo $__env->make('components.rating-stars', ['rating' => $movie->rating], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                </div>

            </div>

        </div>
    </div>
</div>
<!-- Movie List Item -->
<?php /**PATH D:\download\archive\UAS\Cinemat-main\resources\views/components/movie-list-item.blade.php ENDPATH**/ ?>
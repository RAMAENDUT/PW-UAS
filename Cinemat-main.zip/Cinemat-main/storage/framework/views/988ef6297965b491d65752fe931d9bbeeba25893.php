<div class="form-group <?php echo e($classes??''); ?>">
    <label><?php echo e($label); ?></label>
    <input type="<?php echo e($type); ?>"
           name="<?php echo e($name); ?>"
           class="form-control"
           value="<?php echo e($value??''); ?>"
           <?php echo e($required??''); ?>

           <?php echo e($extra_attr??''); ?>>
    <?php echo $__env->make('components.error-message',['field_name'=>$name], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div><?php /**PATH D:\download\archive\UAS\Cinemat-main\resources\views/components/form-input.blade.php ENDPATH**/ ?>
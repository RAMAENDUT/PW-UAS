<?php if( session()->has('flash') ): ?>
<div class="flash-message fixed-bottom bg-light border rounded p-3" style="bottom:15px; right:15px; left:auto;">
    <span class="text-<?php echo e(session('flash')); ?> font-weight-bold"><?php echo e(session('message')); ?></span>
</div>
<?php endif; ?><?php /**PATH D:\download\archive\UAS\Cinemat-main\resources\views/components/flash-message.blade.php ENDPATH**/ ?>
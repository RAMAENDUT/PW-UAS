<div class="form-group <?php echo e($classes??''); ?>">
    <label><?php echo e($label); ?></label>
    <input name="<?php echo e($name); ?>"
           type="time"
           class="form-control"
           value="<?php echo e($value??''); ?>"
           <?php echo e($required??''); ?>>
    <?php echo $__env->make('components.error-message',['field_name'=>$name], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div><?php /**PATH D:\download\archive\UAS\Cinemat-main\resources\views/components/form-time.blade.php ENDPATH**/ ?>
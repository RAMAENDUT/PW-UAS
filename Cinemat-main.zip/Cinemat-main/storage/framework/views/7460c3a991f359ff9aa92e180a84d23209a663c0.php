<!-- ===== All Javascript at the bottom of the page for faster page loading ===== -->
<script src=<?php echo e(asset('js/jquery-3.2.1.min.js')); ?>></script>
<script src=<?php echo e(asset('js/bootstrap.min.js')); ?>></script>
<script src=<?php echo e(asset('js/jquery.ajaxchimp.js')); ?>></script>
<script src=<?php echo e(asset('js/jquery.magnific-popup.min.js')); ?>></script>
<script src=<?php echo e(asset('js/jquery.mmenu.js')); ?>></script>
<script src=<?php echo e(asset('js/jquery.inview.min.js')); ?>></script>
<script src=<?php echo e(asset('js/jquery.countTo.min.js')); ?>></script>
<script src=<?php echo e(asset('js/jquery.countdown.min.js')); ?>></script>
<script src=<?php echo e(asset('js/owl.carousel.min.js')); ?>></script>
<script src=<?php echo e(asset('js/imagesloaded.pkgd.min.js')); ?>></script>
<script src=<?php echo e(asset('js/isotope.pkgd.min.js')); ?>></script>
<script src=<?php echo e(asset('js/headroom.js')); ?>></script>
<script src=<?php echo e(asset('js/custom.js')); ?>></script>

<!-- ===== Slider Revolution core JavaScript files ===== -->
<script type="text/javascript" src=<?php echo e(asset('revolution/js/jquery.themepunch.tools.min.js')); ?>></script>
<script type="text/javascript" src=<?php echo e(asset('revolution/js/jquery.themepunch.revolution.min.js')); ?>></script>

<!-- ===== Slider Revolution extension scripts ===== -->
<script type="text/javascript" src=<?php echo e(asset('revolution/js/extensions/revolution.extension.actions.min.js')); ?>></script>
<script type="text/javascript" src=<?php echo e(asset('revolution/js/extensions/revolution.extension.carousel.min.js')); ?>></script>
<script type="text/javascript" src=<?php echo e(asset('revolution/js/extensions/revolution.extension.kenburn.min.js')); ?>></script>
<script type="text/javascript" src=<?php echo e(asset('revolution/js/extensions/revolution.extension.layeranimation.min.js')); ?>></script>
<script type="text/javascript" src=<?php echo e(asset('revolution/js/extensions/revolution.extension.migration.min.js')); ?>></script>
<script type="text/javascript" src=<?php echo e(asset('revolution/js/extensions/revolution.extension.navigation.min.js')); ?>></script>
<script type="text/javascript" src=<?php echo e(asset('revolution/js/extensions/revolution.extension.parallax.min.js')); ?>></script>
<script type="text/javascript" src=<?php echo e(asset('revolution/js/extensions/revolution.extension.slideanims.min.js')); ?>></script>
<script type="text/javascript" src=<?php echo e(asset('revolution/js/extensions/revolution.extension.video.min.js')); ?>></script>

<?php /**PATH D:\download\archive\UAS\Cinemat-main\resources\views/layouts/includes.blade.php ENDPATH**/ ?>
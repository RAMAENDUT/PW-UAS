<?php $__env->startSection('content'); ?>
<h1 class="h3 mb-4 text-gray-800">Add Movie</h1>
<form action="<?php echo e(route('manager.movies.store')); ?>"
      method="POST" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <div class="row">
        <?php echo $__env->make('components.form-input',[
        'name'=>'image',
        'classes'=>'col-6',
        'label'=>'Poster Image',
        'required'=>'required',
        'type'=>'file',
        ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('components.form-input',[
        'name'=>'title',
        'classes'=>'col-6',
        'label'=>'Image Title*',
        'required'=>'required',
        'type'=>'text',
        'value'=>old('title'),
        ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <div class="row">
        <?php echo $__env->make('components.form-select',[
        'name'=>'category_id',
        'label'=>'Category*',
        'classes'=>'col-6',
        'options'=>$categories,
        'required'=>'required',
        'selected'=> old('category_id'),
        ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('components.form-input',[
        'name'=>'language',
        'classes'=>'col-6',
        'label'=>'Movie Language*',
        'required'=>'required',
        'type'=>'text',
        'value'=>old('language'),
        ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>

    <div class="row">
        <?php echo $__env->make('components.form-input',[
        'name'=>'rating',
        'classes'=>'col-6',
        'label'=>'Movie Rating*',
        'required'=>'required',
        'type'=>'number',
        'value'=>old('rating'),
        'extra_attr'=>'min=0 max=5 step=0.01',
        ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('components.form-date',[
        'name'=>'release_date',
        'label'=>'Movie Release Date*',
        'classes'=>'col-6',
        'value'=>old('release_date'),
        'required'=>'required',
        ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>

    <div class="row">
        <?php echo $__env->make('components.form-input',[
        'name'=>'director',
        'classes'=>'col-6',
        'label'=>'Director*',
        'required'=>'required',
        'type'=>'text',
        'value'=>old('director'),
        ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('components.form-input',[
        'name'=>'maturity_rating',
        'classes'=>'col-6',
        'label'=>'Maturity Rating*',
        'required'=>'required',
        'type'=>'text',
        'value'=>old('maturity_rating'),
        ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <div class="row">
        <?php echo $__env->make('components.form-time',[
        'name'=>'running_time',
        'label'=>'Running Time*',
        'classes'=>'col-6',
        'value'=>old('running_time'),
        'required'=>'required',
        ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('components.form-textarea',[
        'name'=>'storyline',
        'classes'=>'col-6',
        'label'=>'Movie Storyline*',
        'required'=>'required',
        'value'=>old('storyline'),
        ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>

    <div class="row justify-content-end">
        <input class="btn btn-success m-2"
               type="submit"
               value="Save">
    </div>
</form>
<?php echo $__env->make('components.flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('manager.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\download\archive\UAS\Cinemat-main\resources\views/manager/movie-create.blade.php ENDPATH**/ ?>
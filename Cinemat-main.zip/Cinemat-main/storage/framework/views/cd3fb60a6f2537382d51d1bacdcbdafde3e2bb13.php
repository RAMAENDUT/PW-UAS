<?php $__env->startSection('content'); ?>
<h1 class="h3 mb-4 text-gray-800">Manager Requests</h1>
<?php if($users->isNotEmpty()): ?>
<table class="showtime-table table table-striped table-hover rounded">
    <thead class="thead-dark">
        <tr>
            <th scope="col">Username</th>
            <th scope="col">Email</th>
            <th scope="col">Created at</th>
            <th scope="col"></th>
            <th scope="col"></th>
        </tr>
    </thead>
    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr id="<?php echo e($user->id); ?>">
        <th><?php echo e($user->username); ?></th>
        <td><?php echo e($user->email); ?></td>
        <td><?php echo e($user->created_at); ?></td>
        <td class="">
            <form action="<?php echo e(route('users.update',$user->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <input type="hidden" name="accepted" value=1>
                <input class="btn btn-info text-white" type="submit" value="Accept">
            </form>
        </td>
        <td class="">
            <form action="<?php echo e(route('users.update',$user->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <input type="hidden" name="accepted" value=0>
                <input class="btn btn-danger text-white" type="submit" value="Reject">
            </form>
        </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<?php else: ?>
<div class="bg-light p-3 font-weight-bold rounded text-center">
    There are currently no manager requests.
</div>
<?php endif; ?>
<?php echo $__env->make('components.flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\download\archive\UAS\Cinemat-main\resources\views/admin/manager-requests.blade.php ENDPATH**/ ?>
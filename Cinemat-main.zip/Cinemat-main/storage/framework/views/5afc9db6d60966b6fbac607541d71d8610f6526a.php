<?php $__env->startSection('content'); ?>
<h1 class="h3 mb-0 text-gray-800">Movies</h1>
<p>Deleting a movie deletes its shows and subsequent reservations.</p>
<?php if($movies->isNotEmpty()): ?>
<table class="showtime-table table table-striped table-hover rounded">
    <thead class="thead-dark">
        <tr>
            <th scope="col">ID</th>
            <th scope="col">Poster</th>
            <th scope="col">Title</th>
            <th scope="col">Category</th>
            <th scope="col">Rating</th>
            <th scope="col"></th>
            <th scope="col"></th>
        </tr>
    </thead>
    <?php $__currentLoopData = $movies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $movie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <th><?php echo e($movie->id); ?></th>
        <th><img src="<?php echo e(asset('storage/'.$movie->image)); ?>" height="70px"></img></th>
        <th><?php echo e($movie->title); ?></th>
        <td><?php echo e($movie->category->title); ?></td>
        <td><i class="fa fa-star"></i><?php echo e($movie->rating); ?></td>
        <td>
            <a href="<?php echo e(route('manager.movies.edit',$movie->id)); ?>"
               class="btn btn-warning text-white">Edit</a>
        </td>
        <td>
            <form action="<?php echo e(route('manager.movies.destroy',$movie->id)); ?>"
                  method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <input class="btn btn-danger text-white"
                       type="submit"
                       value="Delete">
            </form>
        </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<?php else: ?>
<div class="bg-light p-3 font-weight-bold rounded text-center">
    There are currently no movies.
</div>
<?php endif; ?>
<?php echo $__env->make('components.flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('manager.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\download\archive\UAS\Cinemat-main\resources\views/manager/movie-index.blade.php ENDPATH**/ ?>
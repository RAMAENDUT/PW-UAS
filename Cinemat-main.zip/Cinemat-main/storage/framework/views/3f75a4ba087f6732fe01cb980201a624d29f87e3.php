<?php $__env->startSection('content'); ?>
<h1 class="h3 mb-4 text-gray-800">Users</h1>
<?php if($users->isNotEmpty()): ?>
<table class="showtime-table table table-striped table-hover rounded">
    <thead class="thead-dark">
        <tr>
            <th scope="col">Username</th>
            <th scope="col">Role</th>
            <th scope="col">Email</th>
            <th scope="col"></th>
        </tr>
    </thead>
    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <th><?php echo e($user->username); ?></th>
        <td><?php echo e($user->role->title); ?></td>
        <td><?php echo e($user->email); ?></td>
        <?php if(!$user->isAdmin()): ?>
        <td class="">
            <form action="<?php echo e(route('users.destroy',$user->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('delete'); ?>
                <input class="btn btn-danger text-white" type="submit" value="Delete User">
            </form>
        </td>
        <?php else: ?>
        <td class="">
            <button class="btn btn-danger text-white disabled" type="button">Delete User</button>
        </td>
        <?php endif; ?>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<?php else: ?>
<div class="bg-light p-3 font-weight-bold rounded text-center">
    There are currently no users
</div>
<?php endif; ?>
<?php echo $__env->make('components.flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\download\archive\UAS\Cinemat-main\resources\views/admin/users.blade.php ENDPATH**/ ?>
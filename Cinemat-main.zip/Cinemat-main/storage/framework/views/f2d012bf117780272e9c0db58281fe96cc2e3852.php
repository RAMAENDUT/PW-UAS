<div class="item">
    <!-- Start of Movie Box -->
    <div class="movie-box-1">

        <!-- Start of Poster -->
        <div class="poster">
            <img src="<?php echo e(asset('storage/' . $movie->image)); ?>" alt="">
        </div>
        <!-- End of Poster -->

        <!-- Start of Buttons -->
        <div class="buttons">
            <a href="<?php echo e(route('movies.show', $movie->id)); ?>" class="play-video">
                <i class="fa fa-ticket"></i>
            </a>
        </div>
        <!-- End of Buttons -->

        <!-- Start of Movie Details -->
        <div class="movie-details">
            <h4 class="movie-title">
                <a href="<?php echo e(route('movies.show', $movie->id)); ?>"><?php echo e($movie->title); ?></a>
            </h4>
            <span class="released"><?php echo e($movie->release_date->toFormattedDateString()); ?></span>
        </div>
        <!-- End of Movie Details -->

        <!-- Start of Rating -->
        <div class="stars">
            <div class="rating">
                <?php echo $__env->make('components.rating-stars', ['rating' => $movie->rating], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <span><?php echo e(number_format($movie->rating, 1)); ?>/5</span>
        </div>
        <!-- End of Rating -->

    </div>
    <!-- End of Movie Box -->
</div>
<?php /**PATH D:\download\archive\UAS\Cinemat-main\resources\views/components/movie-item-image.blade.php ENDPATH**/ ?>
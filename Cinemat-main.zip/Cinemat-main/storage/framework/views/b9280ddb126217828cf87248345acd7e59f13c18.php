<!-- =============== START OF RESPONSIVE - MAIN NAV =============== -->
<nav id="main-mobile-nav"></nav>
<!-- =============== END OF RESPONSIVE - MAIN NAV =============== -->

<!-- =============== START OF HEADER NAVIGATION =============== -->
<!-- Insert the class "sticky" in the header if you want a sticky header -->
<header class="header text-black">
    <div class="container-fluid">

        <!-- ====== Start of Navbar ====== -->
        <nav class="navbar navbar-expand-lg">
            <li class="nav-item">
                        <h1 class="nav-link" href=<?php echo e(route('home')); ?>>CINIME</h1>
                    </li>
            </a>

            <!-- Login Button on Responsive -->
            <a href="<?php echo e(route('login')); ?>" class="login-mobile-btn border px-2 py-1"
                style="border-radius: 0.5rem; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; max-width: 35%;">
                <i class="icon-user"></i>
                <?php if(auth()->guard()->check()): ?>
                    <?php echo e(auth()->user()->first_name); ?>

                <?php endif; ?>
            </a>

            <button id="mobile-nav-toggler" class="hamburger hamburger--collapse" type="button">
                <span class="hamburger-box">
                    <span class="hamburger-inner"></span>
                </span>
            </button>

            <!-- ====== Start of #main-nav ====== -->
            <div class="navbar-collapse" id="main-nav">

                <!-- ====== Start of Main Menu ====== -->
                <ul class="navbar-nav mx-auto" id="main-menu">
                    <!-- Menu Item -->
                    <li class="nav-item">
                        <a class="nav-link" href=<?php echo e(route('home')); ?>>Home</a>
                    </li>

                    <!-- Menu Item -->
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('movies.index')); ?>">Movies</a>
                    </li>

                    <!-- Menu Item -->
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('contact-us')); ?>">Contact us</a>
                    </li>

                </ul>
                <!-- ====== End of Main Menu ====== -->


                <!-- ====== Start of Extra Nav ====== -->
                <ul class="navbar-nav extra-nav">

                    <!-- Menu Item -->
                    <?php if(auth()->guard()->check()): ?>
                        <li class="nav-item notification-wrapper">
                            <a class="nav-link notification" href="<?php echo e(route('dashboard')); ?>">
                                <i class="fa fa-ticket"></i>
                                <span class="notification-count"><?php echo e(auth()->user()->reservations->count()); ?></span>
                            </a>
                        </li>
                    <?php endif; ?>

                    <?php if(auth()->guard()->check()): ?>
                        <li class="nav-item dropdown" style="z-index: 50;">
                            <a href="<?php echo e(route('dashboard')); ?>" class="btn btn-main btn-effect login-btn">
                                <i class="icon-user"></i>Hello, <?php echo e(auth()->user()->first_name); ?></a>
                            <div class="dropdown-content rounded font-weight-normal">
                                <a href="<?php echo e(route('dashboard')); ?>">My Account</a>
                                <a href="<?php echo e(route('dashboard')); ?>">My Reservations</a>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin')): ?>
                                    <a href="<?php echo e(route('admin.dashboard')); ?>">Admin Dashboard</a>
                                <?php endif; ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manager')): ?>
                                    <a href="<?php echo e(route('manager.dashboard')); ?>">Manager Dashboard</a>
                                <?php endif; ?>
                                <form id="logout_form" method="POST" action="<?php echo e(route('logout')); ?>">
                                    <?php echo csrf_field(); ?>
                                    <a href="javascript:{}" onclick="document.getElementById('logout_form').submit();">Log
                                        Out</a>
                                </form>
                            </div>
                        </li>
                    <?php else: ?>
                        <li class="nav-item">
                            <a href="<?php echo e(route('login')); ?>" class="btn btn-main btn-effect login-btn">
                                <i class="icon-user"></i>login</a>
                        </li>
                    <?php endif; ?>

                </ul>
                <!-- ====== End of Extra Nav ====== -->

            </div>
            <!-- ====== End of #main-nav ====== -->
        </nav>
        <!-- ====== End of Navbar ====== -->

    </div>
</header>
<!-- =============== END OF HEADER NAVIGATION =============== -->
<?php /**PATH D:\download\archive\UAS\Cinemat-main\resources\views/layouts/header.blade.php ENDPATH**/ ?>
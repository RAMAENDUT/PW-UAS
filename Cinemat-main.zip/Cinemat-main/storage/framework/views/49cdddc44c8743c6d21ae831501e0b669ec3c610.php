<div class="form-group <?php echo e($classes??''); ?>">
    <label><?php echo e($label); ?></label>
    <textarea rows="5"
              name="<?php echo e($name); ?>"
              class="form-control"
              <?php echo e($required??''); ?>

              <?php echo e($extra_attr??''); ?>><?php echo e($value??''); ?></textarea>
    <?php echo $__env->make('components.error-message',['field_name'=>$name], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div><?php /**PATH D:\download\archive\UAS\Cinemat-main\resources\views/components/form-textarea.blade.php ENDPATH**/ ?>
<div class="form-group <?php echo e($classes??''); ?>">
    <label><?php echo $label; ?></label>
    <select name="<?php echo e($name); ?>"
            class="form-control"
            <?php echo e($required??''); ?>>
        <?php $__currentLoopData = $options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if(isset($selected) && $selected == $key): ?>
        <option value="<?php echo e($key); ?>"
                selected><?php echo e($value); ?></option>
        <?php else: ?>
        <option value="<?php echo e($key); ?>"><?php echo e($value); ?></option>
        <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <?php echo $__env->make('components.error-message',['field_name'=>$name], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div><?php /**PATH D:\download\archive\UAS\Cinemat-main\resources\views/components/form-select.blade.php ENDPATH**/ ?>
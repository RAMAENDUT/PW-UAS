<div class="container">
    <h1 class="mt-0 mb-0">My Reservations</h1>
    <hr>
    <?php if($reservations->isNotEmpty()): ?>
        <table class="table table-responsive table-striped table-hover">
            <thead class="thead-dark">
                <tr>
                    <th scope="col">Movie</th>
                    <th scope="col">Show time</th>
                    <th scope="col">Seat number</th>
                    <th scope="col">Show price</th>
                    <th scope="col"></th>
                </tr>
            </thead>
            <?php $__currentLoopData = $reservations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reservation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th><?php echo e($reservation->show->movie->title); ?></th>
                    <th><?php echo e($reservation->show->date->toDayDateTimeString()); ?></th>
                    <td><?php echo e($reservation->seat_number); ?></td>
                    <td><?php echo e($reservation->show->price . ' ' . config('app.currency')); ?></td>
                    <?php if($reservation->show->date > Carbon\Carbon::now()->add(3, 'hour')): ?>
                        <td class="disabled">
                            <form action="<?php echo e(route('reservations.destroy', $reservation->id)); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('delete'); ?>
                                <input class="btn btn-second text-white" type="submit" value="Cancel Reservation">
                            </form>
                        </td>
                    <?php endif; ?>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    <?php else: ?>
        <div class="bg-light p-3 font-weight-bold rounded text-center">
            You don't have any future reservations.
        </div>
    <?php endif; ?>
</div>
<?php /**PATH D:\download\archive\UAS\Cinemat-main\resources\views/user/reservations.blade.php ENDPATH**/ ?>
<?php $__env->startPush('head'); ?>
    <script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js"></script>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <section class="page-header overlay-gradient"
        style="background: url(<?php echo e(asset('images/branding/posters/movie-collection.webp')); ?>);">
        <div class="container">
            <div class="inner">
                <h2 class="title">Movies</h2>
                <ol class="breadcrumb">
                    <li><a href="<?php echo e(route('home')); ?>">Home</a></li>
                    <li>Movies</li>
                </ol>
            </div>
        </div>
    </section>

    <!-- =============== START OF MAIN =============== -->
    <main class="ptb100">
        <div class="container" x-data="{
            layout: 'grid',
            setLayout(newLayout) {
                if (newLayout != 'grid' && newLayout != 'list') return;
                this.layout = newLayout;
                localStorage.setItem('layout', newLayout);
            },
            init() {
                const localLayout = localStorage.layout;
                if (localLayout == 'grid' || localLayout == 'list') {
                    this.layout = localLayout;
                } else {
                    this.layout = 'grid';
                }
            }
        }">

            <!-- Start of Filters -->
            <div class="d-flex mb50 align-items-center justify-content-between">


                <form method="GET" action="<?php echo e(route('movies.index')); ?>" class="d-flex">

                    <input type="search" name="search" id="search" class="py-1 form-control" placeholder="search"
                        style="flex-basis: fit-content" value="<?php echo e(request('search')); ?>">

                    <div class="px-3 py-3 py-xl-0"></div>

                    <div class="d-flex align-items-center">
                        <label for="category" class="pr-1 text-nowrap">Category:</label>
                        <select name="category" id="category" class="py-1">
                            <option value="" default>All Categories</option>
                            <?php $__currentLoopData = \App\Models\Category::CATEGORIES; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($category); ?>"
                                    <?php echo e(request('category') == $category ? 'selected' : ''); ?>>
                                    <?php echo e($category); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="px-3 py-3 py-xl-0"></div>

                    <div class="d-flex align-items-center">
                        <label for="sort" class="pr-1 text-nowrap">Sort by: </label>
                        <?php
                            $sortings = [
                                'default' => 'Default Order',
                                'top-rated' => 'Top Rated',
                                'newest' => 'Newest',
                                'oldest' => 'Oldest',
                            ];
                        ?>
                        <select name="sort" id="sort" class="py-1">
                            <?php $__currentLoopData = $sortings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $sorting): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($value); ?>" <?php echo e(request('sort') == $value ? 'selected' : ''); ?>>
                                    <?php echo e($sorting); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="px-2 py-3 py-xl-0"></div>

                    <input type="submit" value="Filter" class="btn btn-main">

                </form>

                <div class="py-3 py-xl-0"></div>

                <div>
                    <!-- Layout Switcher -->
                    <div class="layout-switcher">
                        <a href="#" class="list" x-bind:class="{ 'active': layout === 'list' }"
                            @click.prevent="setLayout('list')">
                            <i class="fa fa-align-justify"></i>
                        </a>
                        <a href="#" class="grid" x-bind:class="{ 'active': layout === 'grid' }"
                            @click.prevent="setLayout('grid')">
                            <i class="fa fa-th"></i>
                        </a>
                    </div>
                </div>


            </div>
            <!-- End of Filters -->


            <?php if($movies->isEmpty()): ?>
                <p class="bg-light font-weight-bold h4 p-5 rounded text-center">No movies found!</p>
            <?php else: ?>
                <!-- Start of Movie Grid -->
                <div class="row" x-show="layout === 'grid'" x-transition>
                    <?php echo $__env->renderEach('components.movie-grid-item', $movies, 'movie'); ?>
                </div>
                <!-- End of Movie Grid -->

                <!-- Start of Movie List -->
                <div class="row mt100" x-show="layout === 'list'" x-transition>
                    <?php echo $__env->renderEach('components.movie-list-item', $movies, 'movie'); ?>
                </div>
                <!-- End of Movie List -->
            <?php endif; ?>


            <!-- Start of Pagination -->
            <div class="row">
                <div class="col-md-12 col-sm-12">
                    <?php echo $movies->links('pagination::bootstrap-4'); ?>

                </div>
            </div>
            <!-- End of Pagination -->

        </div>
    </main>
    <!-- =============== END OF MAIN =============== -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\download\archive\UAS\Cinemat-main\resources\views/movie/index.blade.php ENDPATH**/ ?>